// ConsoleTest.cpp : Defines the entry point for the console application.
//

#include "stdafx.h"
#include <atlbase.h>

#ifdef _DEBUG
#import "../Bin/Debug/SecurityUtil.dll" no_namespace raw_interfaces_only
#else
#import "../Bin/Release/SecurityUtil.dll" no_namespace raw_interfaces_only
#endif

/*
<%
    var objArray= Server.CreateObject("JALArray.Array") ;
    var arrayVariants= new VBArray(objArray.GetArray(10)); 
    var arrayBSTR= arrayVariants.toArray(); 
    for (i= arrayVariants.lbound();i<= arrayVariants.ubound(); i++) {
        Response.write("<BR>"+i+": "+arrayBSTR[i]+""); 
    }
    objArray= null;
    %> 
*/

#define ACCESS_READ  1
#define ACCESS_WRITE 2

int main(int argc, char* argv[])
{
	printf("Hello World!\n");

	HRESULT hr = S_OK;
	::CoInitialize(NULL);

	ITrusteeUtilPtr pUtil;
	hr = ::CoCreateInstance(__uuidof(TrusteeUtil),
							NULL,
							CLSCTX_SERVER,
							__uuidof(ITrusteeUtil),
							reinterpret_cast<void**>(&pUtil));
	if (FAILED(hr))
	{
		return -1;
	}

	/*
	CComVariant vtNames;
	_bstr_t bstrUser (L"naveen");
	hr = pUtil->GetGroupNamesOfUser(bstrUser, L"", TRUE, &vtNames);
	if (vtNames.vt & VT_ARRAY)
	{
		SAFEARRAY *psa = vtNames.parray;
		if (psa != NULL)
		{
			LONG lBound;
			LONG uBound;
			::SafeArrayGetLBound(psa, 1, &lBound);
			::SafeArrayGetUBound(psa, 1, &uBound);
			for (LONG lIdx = lBound; lIdx <= uBound; lIdx++)
			{
				_variant_t vtVal;
				hr = ::SafeArrayGetElement(psa, &lIdx, &vtVal);
				if (SUCCEEDED (hr))
				{
					if (vtVal.vt & VT_BSTR)
					{
						USES_CONVERSION;
						::OutputDebugString(OLE2T(vtVal.bstrVal));
					}
				}
			}

			::SafeArrayDestroy(psa);
		}
	}
	::VariantClear(&vtNames);
	*/

	LONG bOK;
	CComBSTR bstrUser ("nkohli");
	CComBSTR bstrDomain("develop");
	CComBSTR bstrFile ("C:\\DataFiles");

	//hr = pUtil->CheckUserAccessOnFile(bstrFile, FILE_READ_DATA, &bOK);
	hr = pUtil->CheckPermissionsOnFile(bstrUser, bstrDomain, bstrFile, FILE_WRITE_EA, &bOK);
	if (FAILED (hr))
	{
		::OutputDebugString(_T("Failed."));
	}
	pUtil = NULL;

	::CoUninitialize();
	return 0;
}

