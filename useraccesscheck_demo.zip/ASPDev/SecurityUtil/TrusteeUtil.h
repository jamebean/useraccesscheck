// Disclaimer and Copyright Information
// TrusteeUtil.h : 
//
// All rights reserved.
//
// Written by Pardesi Services, LLC
// Version 1.0
//
// Distribute freely, except: don't remove our name from the source or
// documentation (don't take credit for my work), mark your changes (don't
// get me blamed for your possible bugs), don't alter or remove this
// notice.
// No warrantee of any kind, express or implied, is included with this
// software; use at your own risk, responsibility for damages (if any) to
// anyone resulting from the use of this software rests entirely with the
// user.
//
// Send bug reports, bug fixes, enhancements, requests, flames, etc. to
// softomatix@pardesiservices.com
///////////////////////////////////////////////////////////////////////////////
//	
// TrusteeUtil.h : Declaration of the TrusteeUtil

#ifndef __TRUSTEEUTIL_H_
#define __TRUSTEEUTIL_H_

#include "resource.h"       // main symbols
#include <asptlb.h>         // Active Server Pages Definitions

typedef basic_string<TCHAR> TString;
typedef list<string>		StrList;
/////////////////////////////////////////////////////////////////////////////
// TrusteeUtil
class ATL_NO_VTABLE TrusteeUtil : 
	public CComObjectRootEx<CComMultiThreadModel>,
	public CComCoClass<TrusteeUtil, &CLSID_TrusteeUtil>,
	public ISupportErrorInfo,
	public IDispatchImpl<ITrusteeUtil, &IID_ITrusteeUtil, &LIBID_SECURITYUTILLib>
{
public:
	TrusteeUtil()
	{ 
		m_bstrErrors = _T("");
		m_bIntialized = FALSE;
		m_pUnkMarshaler = NULL;
		m_bOnStartPageCalled = FALSE;
	}

public:

DECLARE_REGISTRY_RESOURCEID(IDR_TRUSTEEUTIL)

DECLARE_PROTECT_FINAL_CONSTRUCT()
DECLARE_GET_CONTROLLING_UNKNOWN()

BEGIN_COM_MAP(TrusteeUtil)
	COM_INTERFACE_ENTRY(ITrusteeUtil)
	COM_INTERFACE_ENTRY(IDispatch)
	COM_INTERFACE_ENTRY(ISupportErrorInfo)
	COM_INTERFACE_ENTRY_AGGREGATE(IID_IMarshal, m_pUnkMarshaler.p)
END_COM_MAP()

	HRESULT FinalConstruct()
	{
		m_bstrErrors = "";
		m_bIntialized = FALSE;
		return CoCreateFreeThreadedMarshaler(
			GetControllingUnknown(), &m_pUnkMarshaler.p);
	}

	void FinalRelease()
	{
		m_pUnkMarshaler.Release();
	}

	CComPtr<IUnknown> m_pUnkMarshaler;

// ISupportsErrorInfo
	STDMETHOD(InterfaceSupportsErrorInfo)(REFIID riid);

// ITrusteeUtil
public:
	STDMETHOD(CheckUserAccessOnFile)(/*[in]*/BSTR bstrFileName, /*[in]*/long lMask, /*[out, retval]*/BOOL *pbIsOK);
	STDMETHOD(CheckPermissionsOnFile)(/*[in]*/BSTR bstrUser, /*[in]*/BSTR bstrDomain, /*[in]*/BSTR bstrFileName, /*[in]*/long lAccessToCheck, /*[out, retval]*/BOOL *pbOK);
	STDMETHOD(GetErrors)(/*[out, retval]*/BSTR *pbstrErrors);
	STDMETHOD(GetGroupNamesOfUser)(/*[in]*/BSTR bstrUser, /*[in]*/BSTR bstrServer, /*[in]*/BOOL bIncludeIndirect, /*[out,retval]*/VARIANT* pvarNames);
	STDMETHOD(Initialize)(/*[in]*/BSTR bstrAdmin, /*[in]*/BSTR bstrPwd);
	//Active Server Pages Methods
	STDMETHOD(OnStartPage)(IUnknown* IUnk);
	STDMETHOD(OnEndPage)();

private:
	
	CComPtr<IRequest> m_piRequest;					//Request Object
	CComPtr<IResponse> m_piResponse;				//Response Object
	CComPtr<ISessionObject> m_piSession;			//Session Object
	CComPtr<IServer> m_piServer;					//Server Object
	CComPtr<IApplicationObject> m_piApplication;	//Application Object
	BOOL m_bOnStartPageCalled;						//OnStartPage successful?
	BOOL m_bIntialized;

	CComBSTR m_bstrErrors;
	CComBSTR m_bstrAdmin;							// Administrative account name
	CComBSTR m_bstrPwd;								// Admin account password.

private:
	BOOL GetGroupsForThisUser(TString strUser, TString strServer, bool bIncludeIndirect, StrList &lstGroups);
	PSID GetUserSID(TString strUser, TString strDomain);
	BOOL GetFileSD(TString strFile, PSECURITY_DESCRIPTOR *pSD, PACL *pACL);
	DWORD GetUserRights(PSID pUserSID, PACL pACL);
	TString GetServerName(const TString &strDomain);

	LPVOID GetWin32ErrMessage(DWORD dwErr);
};

#endif //__TRUSTEEUTIL_H_
