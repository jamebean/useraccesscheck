// Disclaimer and Copyright Information
// TrusteeUtil.cpp : 
//
// All rights reserved.
//
// Written by Pardesi Services, LLC
// Version 1.0
//
// Distribute freely, except: don't remove our name from the source or
// documentation (don't take credit for my work), mark your changes (don't
// get me blamed for your possible bugs), don't alter or remove this
// notice.
// No warrantee of any kind, express or implied, is included with this
// software; use at your own risk, responsibility for damages (if any) to
// anyone resulting from the use of this software rests entirely with the
// user.
//
// Send bug reports, bug fixes, enhancements, requests, flames, etc. to
// softomatix@pardesiservices.com
///////////////////////////////////////////////////////////////////////////////
//

// TrusteeUtil.cpp : Implementation of TrusteeUtil
#include "stdafx.h"
#include "SecurityUtil.h"
#include "TrusteeUtil.h"

#include <comdef.h>
/***************************************************************************/
/*			INCLUDEDS FOR SECURITY AND NETWORK APIs						   */
/*			Dont'e forget to link with NetApi32.lib						   */
#define MAX_USERNAME	20
#define MAX_GROUPNAME	256
#define MAX_PASSWORD	LM20_PWLEN
#include <wchar.h>
#include <lm.h>		// VERY IMPORTANT
#include <Accctrl.h>
#include <Aclapi.h>
/**************************************************************************/
/////////////////////////////////////////////////////////////////////////////
// TrusteeUtil

STDMETHODIMP TrusteeUtil::InterfaceSupportsErrorInfo(REFIID riid)
{
	static const IID* arr[] = 
	{
		&IID_ITrusteeUtil,
	};
	for (int i=0;i<sizeof(arr)/sizeof(arr[0]);i++)
	{
		if (::InlineIsEqualGUID(*arr[i],riid))
			return S_OK;
	}
	return S_FALSE;
}

STDMETHODIMP TrusteeUtil::OnStartPage (IUnknown* pUnk)  
{
	if(!pUnk)
		return E_POINTER;

	CComPtr<IScriptingContext> spContext;
	HRESULT hr;

	// Get the IScriptingContext Interface
	hr = pUnk->QueryInterface(IID_IScriptingContext, (void **)&spContext);
	if(FAILED(hr))
		return hr;

	// Get Request Object Pointer
	hr = spContext->get_Request(&m_piRequest);
	if(FAILED(hr))
	{
		spContext.Release();
		return hr;
	}

	// Get Response Object Pointer
	hr = spContext->get_Response(&m_piResponse);
	if(FAILED(hr))
	{
		m_piRequest.Release();
		return hr;
	}
	
	// Get Server Object Pointer
	hr = spContext->get_Server(&m_piServer);
	if(FAILED(hr))
	{
		m_piRequest.Release();
		m_piResponse.Release();
		return hr;
	}
	
	// Get Session Object Pointer
	hr = spContext->get_Session(&m_piSession);
	if(FAILED(hr))
	{
		m_piRequest.Release();
		m_piResponse.Release();
		m_piServer.Release();
		return hr;
	}

	// Get Application Object Pointer
	hr = spContext->get_Application(&m_piApplication);
	if(FAILED(hr))
	{
		m_piRequest.Release();
		m_piResponse.Release();
		m_piServer.Release();
		m_piSession.Release();
		return hr;
	}
	m_bOnStartPageCalled = TRUE;
	return S_OK;
}

STDMETHODIMP TrusteeUtil::OnEndPage ()  
{
	m_bOnStartPageCalled = FALSE;
	// Release all interfaces
	m_piRequest.Release();
	m_piResponse.Release();
	m_piServer.Release();
	m_piSession.Release();
	m_piApplication.Release();

	return S_OK;
}

/******************************************************************************
 *	Function:
 *	Parameters:
 *	Returns:
 *	Puspose:
 *****************************************************************************/
STDMETHODIMP TrusteeUtil::Initialize(BSTR bstrAdmin, BSTR bstrPwd)
{
	this->m_bstrErrors = L"";
	m_bIntialized = TRUE;
	this->m_bstrAdmin = bstrAdmin;
	this->m_bstrPwd = bstrPwd;

	return S_OK;
}

/******************************************************************************
 *	Function:
 *	Parameters:
 *	Returns:
 *	Puspose:
 *****************************************************************************/
STDMETHODIMP TrusteeUtil::GetGroupNamesOfUser(BSTR bstrUser,
											  BSTR bstrServer,
											  BOOL bIncludeIndirect,
											  VARIANT *pvarNames)
{
	this->m_bstrErrors = L"";
	HRESULT hr = S_OK;
	// Check if the user name is empty or not.
	if (::SysStringLen(bstrUser) == 0)
	{
		hr = AtlReportError(GetObjectCLSID(),
							L"Empty user name specified.",
							IID_ITrusteeUtil,
							E_INVALIDARG);
		return hr;
	}


	StrList gpList;
	TString strUser;
	TString strServer;
	{
		USES_CONVERSION;
		strUser = OLE2T(bstrUser);
		if (::SysStringLen(bstrServer) > 0)
		{
			strServer = OLE2T(bstrServer);
		}
		else
		{
			strServer = _T("");
		}
	}


	BOOL bRet = this->GetGroupsForThisUser(strUser, strServer, (bIncludeIndirect == TRUE), gpList);
	if (bRet == FALSE)
	{
		hr = AtlReportError(GetObjectCLSID(),
							m_bstrErrors.Copy(),
							IID_ITrusteeUtil,
							E_UNEXPECTED);
		return hr;
	}

	int nNumGps = gpList.size();
	if (nNumGps == 0)
	{
		hr = AtlReportError(GetObjectCLSID(),
							L"Failed to find any group information for the user - Zero Length List.",
							IID_ITrusteeUtil,
							E_UNEXPECTED);
		return hr;
	}

	

	SAFEARRAY *psa;
	SAFEARRAYBOUND rgsabound[1];
	rgsabound[0].lLbound = 0;
	rgsabound[0].cElements = nNumGps;

	psa = SafeArrayCreate(VT_VARIANT, 1, rgsabound);
	if (psa == NULL)
	{
		hr = AtlReportError(GetObjectCLSID(),
							L"Failed to create array of strings.",
							IID_ITrusteeUtil,
							E_OUTOFMEMORY);
	}

	HRESULT hr2 = S_OK;
	long lIdx = 0;
	StrList::iterator itr;
	USES_CONVERSION;
	for (itr = gpList.begin(); itr != gpList.end(); ++itr)
	{
		_variant_t vName;
		vName = ::SysAllocString(T2OLE((*itr).c_str()));
		hr2 = ::SafeArrayPutElement(psa, &lIdx, static_cast<void *>(&vName));
		if (FAILED(hr2))
		{
			switch (hr2)
			{
				case DISP_E_BADINDEX:
					m_bstrErrors += _T("The specified index was invalid.");
					break;
				case E_INVALIDARG:
					m_bstrErrors += _T("One of the arguments is invalid.");
					break;
				case E_OUTOFMEMORY:
					m_bstrErrors += _T("Memory could not be allocated for the element.");
					break;
				default:
					m_bstrErrors += _T("Generic error during filling array.");

			}

			::SafeArrayDestroy(psa);
			return FALSE;
		}

		lIdx++;
	}

	::VariantInit(pvarNames);
	pvarNames->vt = VT_VARIANT | VT_ARRAY;
	pvarNames->parray = psa;
	return hr;
}

/******************************************************************************
 *	Function:
 *	Parameters:
 *	Returns:
 *	Puspose:
 *****************************************************************************/
BOOL TrusteeUtil::GetGroupsForThisUser(TString strUser,
									   TString strServer,
									   bool bIncludeIndirect,
									   StrList &lstGroups)
{
	BOOL bRetVal = TRUE;
	// Clear the list parameter.
	lstGroups.clear();

	// Check to make sure that user name is not empty.
	if (strUser.length() == 0)
	{
		m_bstrErrors += L"\nEmpty user name specified.";
		return FALSE;
	}

	if (strUser.length() > MAX_USERNAME)
	{
		m_bstrErrors += L"\nUser name too long.";
		return FALSE;
	}

	wchar_t wchUser[MAX_USERNAME];
	wchar_t wchServer[MAX_USERNAME];

	
	try
	{
		USES_CONVERSION;
		wcscpy(wchUser, T2W(strUser.c_str()));
		if (strServer.length() > 0)
		{
			TString strTemp = _T("\\\\");
			strTemp += strServer;
			wcscpy(wchServer, T2W(strTemp.c_str()));
		}
	}
	catch (...)
	{
		m_bstrErrors += L"Critical: Exception thrown during copying of strings.";
		return FALSE;
	}

	LPLOCALGROUP_USERS_INFO_0 pBuf = NULL;
	DWORD dwLevel = 0;
	DWORD dwFlags = LG_INCLUDE_INDIRECT ;
	DWORD dwPrefMaxLen = MAX_PREFERRED_LENGTH;
	DWORD dwEntriesRead = 0;
	DWORD dwTotalEntries = 0;
	NET_API_STATUS nStatus;

	//
	// Call the NetUserGetLocalGroups function 
	//  specifying information level 0.
	//
	//  The LG_INCLUDE_INDIRECT flag specifies that the 
	//   function should also return the names of the local 
	//   groups in which the user is indirectly a member.
	//
	
	try
	{
		nStatus = NetUserGetLocalGroups((strServer.length() == 0) ? NULL : wchServer,
										wchUser,
										dwLevel,
										(bIncludeIndirect) ? dwFlags : 0,
										(LPBYTE *) &pBuf,
										dwPrefMaxLen,
										&dwEntriesRead,
										&dwTotalEntries);

		if (NERR_Success == nStatus)
		{
			LPLOCALGROUP_USERS_INFO_0 pTmpBuf;
			DWORD i;
			DWORD dwTotalCount = 0;
			
			if ((pTmpBuf = pBuf) != NULL)
			{
				//
				//	Loop through the entries and 
				//  print the names of the local groups 
				//  to which the user belongs. 
				//
				USES_CONVERSION;
				for (i = 0; i < dwEntriesRead; i++)
				{
					if (pTmpBuf == NULL)
					{
						m_bstrErrors += L"\nCRITICAL: An access violation has occurred.";
						bRetVal = FALSE;
						break;
					}
					
					TString strName = W2T(pTmpBuf->lgrui0_name);
					lstGroups.push_back(strName);

					pTmpBuf++;
					dwTotalCount++;
				}
			}

			// Don't forget to clean up.
			NetApiBufferFree(pBuf);
			pBuf = NULL;
		}
		else
		{
			switch (nStatus)
			{
				case ERROR_ACCESS_DENIED:
					m_bstrErrors += L"\nThe user does not have access to the requested information.";
					break;
				case ERROR_MORE_DATA:
					m_bstrErrors += L"\nMore entries are available. Specify a large enough buffer to receive all entries.";
					break;
				case NERR_InvalidComputer:
					m_bstrErrors += L"\nThe computer name is invalid.";
					break;
				case NERR_UserNotFound:
					m_bstrErrors += L"The user name could not be found.";
					break;
				default:
					m_bstrErrors += L"\nGeneric Win32 Error.";

			}
		}
	}
	catch (...)
	{
		m_bstrErrors += L"\nCRITICAL: An access violation has occurred.";
		bRetVal = FALSE;
	}

	if (NULL != pBuf)
	{
		try
		{
			NetApiBufferFree(pBuf);
		}
		catch (...)
		{
			m_bstrErrors += L"\nCRITICAL: An access violation has occurred during freeing of memory.";
		}
	}

	return bRetVal;
}

/******************************************************************************
 *	Function:
 *	Parameters:
 *	Returns:
 *	Puspose:
 *****************************************************************************/
STDMETHODIMP TrusteeUtil::GetErrors(BSTR *pbstrErrors)
{
	if (pbstrErrors != NULL)
	{
		*pbstrErrors = this->m_bstrErrors.Copy();
	}

	return S_OK;
}

/******************************************************************************
 *	Function:
 *	Parameters:
 *	Returns:
 *	Puspose:
 *****************************************************************************/
STDMETHODIMP TrusteeUtil::CheckPermissionsOnFile(BSTR bstrUser,
												 BSTR bstrDomain,
												 BSTR bstrFileName,
												 long lAccessToCheck,
												 BOOL *pbOK)
{
	HRESULT hr = S_OK;
	if (pbOK == NULL)
	{
		hr = AtlReportError(GetObjectCLSID(),
							L"Invalid memory buffer specified for output parameter.",
							IID_ITrusteeUtil,
							E_INVALIDARG);
		return hr;
	}

	*pbOK = FALSE;

	// Make sure that file name and user name strings are not empty.
	if (::SysStringLen(bstrUser) == 0)
	{
		hr = AtlReportError(GetObjectCLSID(),
							L"No user name specified.",
							IID_ITrusteeUtil,
							E_INVALIDARG);
		return hr;
	}

	if (::SysStringLen(bstrFileName) == 0)
	{
		hr = AtlReportError(GetObjectCLSID(),
							L"No user name specified.",
							IID_ITrusteeUtil,
							E_INVALIDARG);
		return hr;
	}

	TString strUser;
	TString strFileName;
	TString strDomain;
	{
		USES_CONVERSION;
		strUser = OLE2T(bstrUser);
		strFileName = OLE2T(bstrFileName);
		if (::SysStringLen(bstrDomain) != 0)
		{
			strDomain = OLE2T(bstrDomain);
		}
	}

	int iRet = -1;
	DWORD lRetMask = 0;
	BOOL bRetVal = FALSE;
	PACL pFileDACL = NULL;
	PSID pUserSID = NULL;
	PSECURITY_DESCRIPTOR pFileSD = NULL;
	// Get the user's SID.
	try
	{
		pUserSID = this->GetUserSID(strUser, strDomain);
	}
	catch (...)
	{
		m_bstrErrors += _T("Exception thrown during SID find operation.");
		hr = AtlReportError(GetObjectCLSID(),
							L"Failed to get user's SID.",
							IID_ITrusteeUtil,
							E_UNEXPECTED);

		goto CleanUp;
	}

	if (NULL == pUserSID)
	{
		m_bstrErrors += _T("Failed to get user SID.");
		hr = AtlReportError(GetObjectCLSID(),
							L"Failed to get user's SID.",
							IID_ITrusteeUtil,
							E_UNEXPECTED);

		goto CleanUp;
	}

	// Get DACL for the file.
	try
	{
		bRetVal = this->GetFileSD(strFileName, &pFileSD, &pFileDACL);
		if (FALSE == bRetVal)
		{
			hr = AtlReportError(GetObjectCLSID(),
							L"Failed to get file's DACL and SD.",
							IID_ITrusteeUtil,
							E_UNEXPECTED);
			goto CleanUp;
		}
	}
	catch (...)
	{
		m_bstrErrors += _T("Exception thrown during DACL find operation.");
		hr = AtlReportError(GetObjectCLSID(),
							L"Failed to get file's DACL.",
							IID_ITrusteeUtil,
							E_UNEXPECTED);

		goto CleanUp;
	}

	// If NULL DACL is present for the file that means that all access is present
	// for this file. Therefore user has all the permissions.
	if (NULL == pFileDACL)
	{
		hr = S_OK;
		*pbOK = TRUE;
		goto CleanUp;
	}

	lRetMask = this->GetUserRights(pUserSID, pFileDACL);
	if (lRetMask & lAccessToCheck)
	{
		*pbOK = TRUE;
	}
	else
	{
		*pbOK = FALSE;
	}

CleanUp:

	if (pFileSD != NULL)
	{
		LocalFree(pFileSD);
	}
	if (NULL != pUserSID)
	{
		::HeapFree(::GetProcessHeap(), 0, pUserSID);
		pUserSID = NULL;
	}

	return hr;
}

/******************************************************************************
 *	Function:
 *	Parameters:
 *	Returns:
 *	Puspose:
 *****************************************************************************/
PSID TrusteeUtil::GetUserSID(TString strUser, TString strDomain)
{
	BOOL bRetVal = FALSE;

	if (strUser.length == 0)
	{
		this->m_bstrErrors += L"\nEmpty user name specified.";
		return NULL;
	}

	TString strDCServer = "";
	// Before we lok up the SId, we need to get the domain controller server 
	// name if caller has specified a domain name.
	if (strDomain.length() != 0)
	{
		strDCServer = this->GetServerName(strDomain);
	}

	
	DWORD			cbDomain = 0;
	DWORD			cbUserSID = 0;
	SID_NAME_USE	snuType;
	TCHAR			*pszDomain = NULL;
	LPVOID			pUserSID = NULL;

	bRetVal = ::LookupAccountName((strDCServer.length() == 0) ? NULL : strDCServer.c_str(),
								  strUser.c_str(),
								  pUserSID,
								  &cbUserSID,
								  pszDomain,
								  &cbDomain,
								  &snuType);
	if (FALSE == bRetVal)
	{
		DWORD dwErr = ::GetLastError();
		if (dwErr != ERROR_INSUFFICIENT_BUFFER)
		{
			LPTSTR pszMessage = (LPTSTR)this->GetWin32ErrMessage(dwErr);
			if (NULL != pszMessage)
			{
				this->m_bstrErrors += pszMessage;
				::LocalFree(pszMessage);
				pszMessage = NULL;
			}

			return NULL;
		}

		pUserSID = ::HeapAlloc(GetProcessHeap(), HEAP_ZERO_MEMORY, cbUserSID);
		if (NULL == pUserSID)
		{
			m_bstrErrors += _T("Failed to allocate memory for SID buffer.");
			return NULL;
		}

		pszDomain = (TCHAR*)::HeapAlloc(GetProcessHeap(), HEAP_ZERO_MEMORY, cbDomain * sizeof(TCHAR));
		if (NULL == pszDomain)
		{
			m_bstrErrors += _T("Failed to allocate memory for domain name buffer.");
			if (pUserSID != NULL)
			{
				::HeapFree(GetProcessHeap(), 0, pUserSID);
				pUserSID = NULL;
			}
			return NULL;
		}

		bRetVal = ::LookupAccountName((strDCServer.length() == 0) ? NULL : strDCServer.c_str(),
									  strUser.c_str(),
									  pUserSID,
									  &cbUserSID,
									  pszDomain,
									  &cbDomain,
									  &snuType);
		if (FALSE == bRetVal)
		{
			dwErr = ::GetLastError();
			LPTSTR pszMessage = (LPTSTR)this->GetWin32ErrMessage(dwErr);
			if (NULL != pszMessage)
			{
				this->m_bstrErrors += pszMessage;
				::LocalFree(pszMessage);
				pszMessage = NULL;
			}

			if (NULL != pUserSID)
			{
				::HeapFree(GetProcessHeap(), 0, pUserSID);
				pUserSID = NULL;
			}

			if (NULL != pszDomain)
			{
				::HeapFree(GetProcessHeap(), 0, pszDomain);
				pUserSID = NULL;
			}
			return NULL;
		}
	}

	if (NULL != pszDomain)
	{
		::HeapFree(GetProcessHeap(), 0, pszDomain);
		pszDomain = NULL;
	}
	return pUserSID;
}

/******************************************************************************
 *	Method:
 *	Parameters:
 *	Return:
 *	Purpose:
 *****************************************************************************/
BOOL TrusteeUtil::GetFileSD(TString strFile, PSECURITY_DESCRIPTOR *pFileSD, PACL *pACL)
{
	BOOL					bRetVal = FALSE;
	DWORD					dwErr = 0;
	SECURITY_INFORMATION	secInfo = DACL_SECURITY_INFORMATION;

	if (strFile.length() == 0)
	{
		m_bstrErrors += _T("empty file name specified.");
		return FALSE;
	}

	HANDLE hFile = ::CreateFile(strFile.c_str(),
								READ_CONTROL,
								0,
								NULL,
								OPEN_EXISTING,
								FILE_ATTRIBUTE_NORMAL | FILE_FLAG_BACKUP_SEMANTICS,
								NULL);
	if (hFile == INVALID_HANDLE_VALUE)
	{
		dwErr = ::GetLastError();
		LPTSTR pszMessage = (LPTSTR)this->GetWin32ErrMessage(dwErr);
		if (NULL != pszMessage)
		{
			this->m_bstrErrors += pszMessage;
			::LocalFree(pszMessage);
			pszMessage = NULL;
		}
		return FALSE;
	}

	dwErr = ::GetSecurityInfo(hFile,
							  SE_FILE_OBJECT,
							  secInfo,
							  NULL,
							  NULL,
							  pACL,
							  NULL,
							  pFileSD);
	if (dwErr != ERROR_SUCCESS)
	{
		LPTSTR pszMessage = (LPTSTR)this->GetWin32ErrMessage(dwErr);
		if (NULL != pszMessage)
		{
			this->m_bstrErrors += pszMessage;
			::LocalFree(pszMessage);
			pszMessage = NULL;
		}

		::CloseHandle(hFile);
		return FALSE;
	}

	::CloseHandle(hFile);
	return TRUE;
}

/******************************************************************************
 *	Method:
 *	Parameters:
 *	Return:
 *	Purpose:
 *****************************************************************************/
DWORD TrusteeUtil::GetUserRights(PSID pUserSID, PACL pACL)
{
	DWORD dwRetVal = 0;
	if (NULL == pUserSID)
	{
		m_bstrErrors += _T("Null User SID specified.");
		return 0;
	}

	if (NULL == pACL)
	{
		m_bstrErrors += _T("Null ACL specified.");
		return 0;
	}

	// Build TRUSTEE structure from SID.
	PTRUSTEE pTrustee = new TRUSTEE();
	if (pTrustee == NULL)
	{
		m_bstrErrors += _T("Failed to allocate memory for TRUSTEE.");
		return 0;
	}

	// Build the trustee from SID.
	BuildTrusteeWithSid(pTrustee, pUserSID);

	// Get the effective rights for the user.
	ACCESS_MASK mask;
	dwRetVal = ::GetEffectiveRightsFromAcl(pACL,
										   pTrustee,
										   &mask);
	if (dwRetVal != ERROR_SUCCESS)
	{
		LPTSTR pszMessage = (LPTSTR)this->GetWin32ErrMessage(dwRetVal);
		if (NULL != pszMessage)
		{
			m_bstrErrors += pszMessage;
			::LocalFree(pszMessage);
			pszMessage = NULL;
		}
		return 0;
	}

	return mask;
}

/******************************************************************************
 *	Method:
 *	Parameters:
 *	Return:
 *	Purpose:
 *****************************************************************************/
LPVOID TrusteeUtil::GetWin32ErrMessage(DWORD dwErr)
{
	LPVOID lpMsgBuf;
	::FormatMessage (FORMAT_MESSAGE_ALLOCATE_BUFFER |
					 FORMAT_MESSAGE_FROM_SYSTEM |
					 FORMAT_MESSAGE_IGNORE_INSERTS,
					 NULL,
					 dwErr,
					 MAKELANGID(LANG_NEUTRAL, SUBLANG_DEFAULT), // Default language
					 (LPTSTR) &lpMsgBuf,
					 0,
					 NULL
					 );

	return lpMsgBuf;
}

/******************************************************************************
 *	Method:
 *	Parameters:
 *	Return:
 *	Purpose:
 *****************************************************************************/
STDMETHODIMP TrusteeUtil::CheckUserAccessOnFile(BSTR bstrFileName,
												long lMask,
												BOOL *pbIsOK)
{
	/*
		For Now This Method Has Been Deactivated. Need Some More
		Reasearch.
	*/

	return E_NOTIMPL;

	BOOL bRet = FALSE;
	DWORD dwErr = 0;
	HANDLE hPrevToken;
	TString strFile;
	{
		USES_CONVERSION;
		strFile = OLE2T(bstrFileName);
	}

	// AccessCheck() requires an impersonation token
	ImpersonateSelf(SecurityImpersonation);

	bRet = ::OpenThreadToken(GetCurrentThread(),
							 TOKEN_QUERY,
							 TRUE,
							 &hPrevToken);
	if (FALSE == bRet)
	{
		dwErr = ::GetLastError();
		if (dwErr != ERROR_NO_TOKEN)
		{
			LPTSTR pszMessage = (LPTSTR)this->GetWin32ErrMessage(dwErr);
			if (NULL != pszMessage)
			{
				m_bstrErrors += pszMessage;
				::LocalFree(pszMessage);
				pszMessage = NULL;
			}
			RevertToSelf();
			return E_UNEXPECTED;
		}

		bRet = ::OpenProcessToken(GetCurrentProcess(), TOKEN_QUERY, &hPrevToken);
		if (FALSE == bRet)
		{
			dwErr = ::GetLastError();
			LPTSTR pszMessage = (LPTSTR)this->GetWin32ErrMessage(dwErr);
			if (NULL != pszMessage)
			{
				m_bstrErrors += pszMessage;
				::LocalFree(pszMessage);
				pszMessage = NULL;
			}
			RevertToSelf();
			return E_UNEXPECTED;
		}
	}

	// Get file's security descriptor.
	PACL pACL = NULL;
	PSECURITY_DESCRIPTOR pFileSD = NULL;
	bRet = this->GetFileSD(strFile, &pFileSD, &pACL);
	if (FALSE == pFileSD || NULL == pFileSD)
	{
		RevertToSelf();
		return E_UNEXPECTED;
	}

	// Check if the SD is valid or not.
	bRet = ::IsValidSecurityDescriptor(pFileSD);
	if (FALSE == bRet)
	{
		m_bstrErrors += _T("IsValidSecurityDescriptor: Fail");
		dwErr = ::GetLastError();
		LPTSTR pszMessage = (LPTSTR)this->GetWin32ErrMessage(dwErr);
		if (NULL != pszMessage)
		{
			m_bstrErrors += pszMessage;
			::LocalFree(pszMessage);
			pszMessage = NULL;
		}
		::HeapFree(GetProcessHeap(), 0, pFileSD);
		RevertToSelf();
		return E_UNEXPECTED;
	}

	BOOL bStatus;
	GENERIC_MAPPING genMapping;
	PRIVILEGE_SET   pset;
	DWORD  dwStructSize = sizeof(PRIVILEGE_SET);
	DWORD dwGrantedAccess;

	genMapping.GenericRead    = ACCESS_READ;
	genMapping.GenericWrite   = ACCESS_WRITE;
	genMapping.GenericExecute = 0;
	genMapping.GenericAll     = ACCESS_READ | ACCESS_WRITE;

	bRet = ::AccessCheck(pFileSD,
						 hPrevToken,
						 lMask,
						 &genMapping,
						 &pset,
						 &dwStructSize,
						 &dwGrantedAccess,
						 &bStatus);
	if (FALSE == bRet)
	{
		dwErr = ::GetLastError();
		LPTSTR pszMessage = (LPTSTR)this->GetWin32ErrMessage(dwErr);
		if (NULL != pszMessage)
		{
			m_bstrErrors += pszMessage;
			::LocalFree(pszMessage);
			pszMessage = NULL;
		}

		// Free the SID buffer.
		::HeapFree(GetProcessHeap(), 0, pFileSD);
		RevertToSelf();
		return E_UNEXPECTED;
	}

	RevertToSelf();
	*pbIsOK = bStatus;
	::HeapFree(GetProcessHeap(), 0, pFileSD);
	return S_OK;
}

/******************************************************************************
 *	Method:
 *	Parameters:
 *	Return:
 *	Purpose:
 *****************************************************************************/
TString TrusteeUtil::GetServerName(const TString &strDomain)
{
	// Get the Domain Controller name.
	NET_API_STATUS nStatus;
	LPWSTR lpszPrimaryDC = NULL;
	WCHAR szDomainName[MAX_PATH];

	{
		USES_CONVERSION;
		wcscpy(szDomainName, T2W(strDomain.c_str()));
	}

	nStatus = ::NetGetDCName(NULL, szDomainName, (LPBYTE *)&lpszPrimaryDC);
	if (nStatus != NERR_Success)
	{
		return _T("");
	}

	USES_CONVERSION;

	// Create the local copy of the server name string that will
	// will returned to the caller.
	TString strRet (W2T(lpszPrimaryDC));

	// Make sure that buffer returned by NetGetDCName gets released before
	// exiting the function.
	::NetApiBufferFree(lpszPrimaryDC);

	return strRet;
}
